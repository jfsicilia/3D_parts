                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1920636
Playmobil Rescue Helicopter Tail Rotor by pefozzy is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

My niece and nephew's Playmobil rescue helicopter had a broken tail rotor. This part is a snap-on direct replacement. You may have to ream out with an appropriately sized drill bit after printing so it freely spins.

# Print Settings

Printer: Prusa i3 MK2
Rafts: No
Supports: No
Resolution: 0.2mm
Infill: 25%

Notes: 
I used white ABS- orange or red would be better!

# Post-Printing

clean out center hole with drill bit so it spins freely.

# How I Designed This

I used Onshape to design the part. I included both .STL and solidworks parts here for remixing. 

The onshape file is located here:
https://cad.onshape.com/documents/4bc27824cae85ad62f9ddf4a/w/d1735b698ef50b4bb2530dfc/e/e80ed9c287d0438e974be50a